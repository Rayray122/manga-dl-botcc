start_text = '''Welcome to Manga DL Bot. Here you can Download all Mangas for Free.

Please read the Instructions carefully before surfing in...

Use /help to know commands and how to use this bot'''

help_text = '''List of commands:

/manga <name of Manga you want> : to download any Manga by search

/read : <name of Manga you want to read>
                               
The files provided are in multiple qualities to download just open filein chrome
                               
To report any Problems, Bugs, Suggestions go to @anime_hubon'''

