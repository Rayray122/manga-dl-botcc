![logo](https://telegra.ph/file/5809e7a5cef81fb1e9b59.jpg)
<h1 align="center">𝓜𝓪𝓷𝓰𝓪 𝓓𝓛 𝓑𝓸𝓽</h1>

<b>A Bot which uses unofficial  kissmanga api to search and provide manga respectively to the user.</b>



[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)

<b>Note</b>: <i>If you fork this code give crdites to Dev and ownner of API is , Without API We conot make this code Anymore!</i>
<details>
  <summary>Commands Available: </summary>

<pre>/start</pre>: Cool command to check if bot is working.
<pre>/manga</pre>: Gets you Manga.
<pre>/read</pre>:  Read by manga chapters.
<pre>/nh</pre>: To Get Adult Manga by codes , Example : /nh 339989
</details>


## Environment Variables

To run this project, you will need to add the following environment variables to your .env file

`API_ID` You Can Get it from [here](https://my.telegram.org/) .

`API_HASH` You Can Get it form [here](https://my.telegram.org/) .

`BOT_TOKEN` Search [@BotFather](https://t.me/botfather) in telegram.

## Deployment 

### Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Achu2234/Heroku-Manga-DL-Bot)


Can be found in telegram as [𝓜𝓪𝓷𝓰𝓪 𝓓𝓛 𝓑𝓸𝓽](https://t.me/mangdl_Robot)!



## Creator

- [Achu biju](https://github.com/Achu2234/Heroku-Manga-DL-Bot)Dev
- [MiyukiKun](https://github.com/MiyukiKun?tab=repositories) Dev
- Special thanks to [BaraniARR](https://github.com/BaraniARR/gogoanimeapi) for the base of unofficial gogoanime api


